﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.ZeleznicaDB.EntityFrameworkDB {
    public class ZeleznicaDbContext : DbContext {
        public DbSet<Put> Putevi { get; set; }
        public DbSet<Stanica> Stanice { get; set; }
        public DbSet<Mesto> Mesta { get; set; }
        public DbSet<Kolosek> Koloseci { get; set; }
    }
}
