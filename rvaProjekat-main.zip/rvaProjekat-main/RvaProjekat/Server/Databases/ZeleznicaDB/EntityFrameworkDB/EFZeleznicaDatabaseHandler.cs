﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.ZeleznicaDB.EntityFrameworkDB {
    public class EFZeleznicaDatabaseHandler : IZeleznicaDatabaseHandler {
        static EFZeleznicaDatabaseHandler() {
            System.Data.Entity.Database.SetInitializer<ZeleznicaDbContext>(new DropCreateDatabaseAlways<ZeleznicaDbContext>());
        }

        public bool Create(Put newPut) {
            using (var dbContext = new ZeleznicaDbContext()) {
                if (Read(newPut.Naziv, dbContext) != null) {
                    return false;
                }

                var stanice = new List<Stanica>();

                foreach (var stanica in newPut.Stanice) {
                    Stanica existingStanica = dbContext.Stanice.Find(stanica.Id);
                    if (existingStanica != null) {
                        dbContext.Stanice.Attach(existingStanica);
                        stanice.Add(existingStanica);
                    } else {
                        stanice.Add(stanica);
                    }
                }

                newPut.Stanice = stanice;

                dbContext.Putevi.Add(newPut);
                dbContext.SaveChanges();
            }

            return true;
        }

        public bool CreateStanica(Stanica newStanica)
        {
            using (var dbContext = new ZeleznicaDbContext())
            {
                if (Read(newStanica.Naziv, dbContext) != null)
                {
                    return false;
                }

                dbContext.Stanice.Add(newStanica);
                dbContext.SaveChanges();
            }

            return true;
        }

        public Put Read(string naziv) {
            using (var dbContext = new ZeleznicaDbContext()) {
                foreach (Put put in dbContext.Putevi.Include(p => p.Stanice.Select(s => s.Koloseci)).Include(p => p.Stanice.Select(s => s.Mesto))) {
                    if (put.Naziv == naziv) {
                        return put;
                    }
                }

                return null;
            }
        }

        public List<Put> ReadAll() {
            using (var dbContext = new ZeleznicaDbContext()) {
                return dbContext.Putevi.Include(p => p.Stanice.Select(s => s.Koloseci)).Include(p => p.Stanice.Select(s => s.Mesto)).ToList();
            }
        }

        public bool Update(string oldNaziv, Put updatedPut) {
            using (var dbContext = new ZeleznicaDbContext()) {
                Put existingPut = Read(oldNaziv, dbContext);

                if (existingPut == null) {
                    return false;
                }
                else if((oldNaziv != updatedPut.Naziv) && Read(updatedPut.Naziv, dbContext) != null )
                {
                    return false;
                }

                var stanice = new List<Stanica>();

                foreach (var stanica in updatedPut.Stanice) {
                    Stanica existingStanica = dbContext.Stanice.Find(stanica.Id);
                    if (existingStanica != null) {
                        dbContext.Stanice.Attach(existingStanica);
                        stanice.Add(existingStanica);
                    } else {
                        stanice.Add(stanica);
                    }
                }

                updatedPut.Stanice = stanice;

                dbContext.Putevi.Remove(existingPut);
                dbContext.Putevi.Add(updatedPut);

                dbContext.SaveChanges();
            }

            return true;
        }

        public void Delete(string naziv) {
            using (var dbContext = new ZeleznicaDbContext()) {
                Put putToDelete = Read(naziv, dbContext);
                if (putToDelete == null) {
                    return;
                }
                dbContext.Putevi.Remove(putToDelete);
                dbContext.SaveChanges();
            }
        }

        private Put Read(string naziv, ZeleznicaDbContext dbContext) {
            foreach (Put put in dbContext.Putevi.Include(p => p.Stanice.Select(s => s.Koloseci)).Include(p => p.Stanice.Select(s => s.Mesto))) {
                if (put.Naziv == naziv) {
                    return put;
                }
            }

            return null;
        }

        public List<Stanica> ReadAllStanice()
        {
            using (var dbContext = new ZeleznicaDbContext())
            {
                return dbContext.Stanice.Include(s => s.Koloseci).Include(s => s.Mesto).ToList();
            }
        }

        public List<Stanica> ReadAllStaniceForPut(string nazivPuta) {
            Put put = Read(nazivPuta);
            return put.Stanice;
        }
    }
}
