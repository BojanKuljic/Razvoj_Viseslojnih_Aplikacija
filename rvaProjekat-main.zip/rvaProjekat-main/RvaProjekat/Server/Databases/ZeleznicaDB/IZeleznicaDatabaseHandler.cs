﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.ZeleznicaDB {
    public interface IZeleznicaDatabaseHandler {
        bool Create(Put newPut);
        bool CreateStanica(Stanica newStanica);
        Put Read(string naziv);
        List<Put> ReadAll();
        bool Update(string oldNaziv, Put updatedPut);
        void Delete(string naziv);

        List<Stanica> ReadAllStanice();
        List<Stanica> ReadAllStaniceForPut(string nazivPut);
    }
}
