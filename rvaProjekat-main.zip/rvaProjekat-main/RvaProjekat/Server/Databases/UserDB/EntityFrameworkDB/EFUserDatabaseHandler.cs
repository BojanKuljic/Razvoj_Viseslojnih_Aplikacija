﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.UserDB.EntityFrameworkDB {
    public class EFUserDatabaseHandler : IUserDatabaseHandler {
        static EFUserDatabaseHandler() {
            System.Data.Entity.Database.SetInitializer<UserDbContext>(new DropCreateDatabaseAlways<UserDbContext>());
        }

        public bool Create(User newUser) {
            using (var dbContext = new UserDbContext()) {
                if (Read(newUser.Username, dbContext) != null) {
                    return false;
                }

                dbContext.Users.Add(newUser);
                dbContext.SaveChanges();
            }

            return true;
        }

        public User Read(string username)
        {
            using (var dbContext = new UserDbContext())
            {
                User existingUser = Read(username, dbContext);
                if (existingUser == null)
                {
                    return null;
                }
                return existingUser;
            }
        }

        public bool UpdateName(string username, string newFirstName, string newLastName) {
            using (var dbContext = new UserDbContext()) {
                User existingUser = Read(username, dbContext);
                if (existingUser == null) {
                    return false;
                }

                existingUser.FirstName = newFirstName;
                existingUser.LastName = newLastName;

                dbContext.SaveChanges();
            }

            return true;
        }

        private User Read(string username, UserDbContext dbContext) {
            foreach (User user in dbContext.Users) {
                if (user.Username == username) {
                    return user;
                }
            }

            return null;
        }
    }
}
