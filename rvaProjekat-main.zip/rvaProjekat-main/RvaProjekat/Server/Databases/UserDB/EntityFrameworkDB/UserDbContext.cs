﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.UserDB.EntityFrameworkDB {
    public class UserDbContext : DbContext {
        public DbSet<User> Users { get; set; }
    }
}
