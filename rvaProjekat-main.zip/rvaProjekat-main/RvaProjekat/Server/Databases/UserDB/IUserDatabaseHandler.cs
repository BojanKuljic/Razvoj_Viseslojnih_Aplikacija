﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Databases.UserDB {
    public interface IUserDatabaseHandler {
        bool Create(User newUser);
        User Read(string username);
        bool UpdateName(string username, string newFirstName, string newLastName);
    }
}
