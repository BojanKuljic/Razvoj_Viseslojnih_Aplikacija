﻿using Common.Logger;
using Common.Model;
using Common.WCFContracts;
using Server.Databases.UserDB;
using Server.Databases.UserDB.EntityFrameworkDB;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using ConcurrencyMode = System.ServiceModel.ConcurrencyMode;

namespace Server.WCFServices {
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class UserService : IUserContract {
        IUserDatabaseHandler dbHandler;

        public UserService() {
            dbHandler = new EFUserDatabaseHandler();

            string clientIpAddress = ((RemoteEndpointMessageProperty)OperationContext.Current.IncomingMessageProperties[RemoteEndpointMessageProperty.Name]).Address;
            TxtLogger.Instance.Log("Client '" + clientIpAddress + "' connected", LogLevel.Info);
        }

        public bool AddUser(User newUser) {
            try {
                bool result = dbHandler.Create(newUser);
                return result;
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return false;
            }
        }

        public User AuthenticateUser(string username, string password) {
            try {
                User user = dbHandler.Read(username);
                if (user != null && user.Password == password) {
                    return user;
                }
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
            }

            return null;
        }

        public bool UpdateUsersName(string username, string newFirstName, string newLastName) {
            try {
                return dbHandler.UpdateName(username, newFirstName, newLastName);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return false;
            }
        }
    }
}
