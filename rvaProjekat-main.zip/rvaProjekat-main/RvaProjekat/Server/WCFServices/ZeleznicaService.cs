﻿using Common.Logger;
using Common.Model;
using Common.WCFContracts;
using Server.Databases.UserDB;
using Server.Databases.UserDB.EntityFrameworkDB;
using Server.Databases.ZeleznicaDB;
using Server.Databases.ZeleznicaDB.EntityFrameworkDB;
using Server.PutSearchStrategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using ConcurrencyMode = System.ServiceModel.ConcurrencyMode;

namespace Server.WCFServices {
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class ZeleznicaService : IZeleznicaContract {
        IZeleznicaDatabaseHandler dbHandler;

        public ZeleznicaService() {
            dbHandler = new EFZeleznicaDatabaseHandler();
        }

        public bool AddPut(Put newPut) {
            try {
                return dbHandler.Create(newPut);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return false;
            }
        }

        public void DeletePut(string naziv) {
            try {
                dbHandler.Delete(naziv);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
            }
        }

        public string DuplicatePut(string naziv) {
            try {
                Put put = dbHandler.Read(naziv);
                if (put == null) {
                    return null;
                }

                Put newPut = new Put() { Oznaka = put.Oznaka, Stanice = put.Stanice };

                if (put.Naziv[put.Naziv.Length - 1] == ')') {
                    for (int i = 1; i < 100; i++) {
                        newPut.Naziv = String.Format(put.Naziv.Substring(0, put.Naziv.Length - 1) + ".{0})", i);
                        if (dbHandler.Create(newPut)) {
                            return newPut.Naziv;
                        }
                    }

                } else {
                    for (int i = 1; i < 100; i++) {
                        newPut.Naziv = String.Format(naziv + " ({0})", i);
                        if (dbHandler.Create(newPut)) {
                            return newPut.Naziv;
                        }
                    }
                }
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
            }

            return null;
        }

        public List<Put> FindPutevi(string searchQuery, IPutSearchStrategy putSearchStrategy) {
            try {
                return putSearchStrategy.FindPutevi(searchQuery, dbHandler.ReadAll());
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return new List<Put>();
            }
        }

        public List<Put> GetAllPutevi() {
            try {
                return dbHandler.ReadAll();
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return new List<Put>();
            }
        }

        public bool UpdatePut(string oldNaziv, Put updatedPut) {
            try {
                return dbHandler.Update(oldNaziv, updatedPut);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return false;
            }
        }

        public List<Stanica> GetAllStanice() {
            try {
                return dbHandler.ReadAllStanice();
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return new List<Stanica>();
            }
        }

        public List<Stanica> GetAllStaniceForPut(string nazivPuta) {
            try {
                return dbHandler.ReadAllStaniceForPut(nazivPuta);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return new List<Stanica>();
            }
        }

        public bool AddStanica(Stanica newStanica) {
            try {
                return dbHandler.CreateStanica(newStanica);
            } catch (Exception ex) {
                TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                return false;
            }
        }
    }
}
