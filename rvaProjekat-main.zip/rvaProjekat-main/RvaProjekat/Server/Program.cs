﻿using Common.Logger;
using Common.Model;
using Common.WCFContracts;
using Server.Databases.UserDB;
using Server.Databases.UserDB.EntityFrameworkDB;
using Server.Databases.ZeleznicaDB;
using Server.Databases.ZeleznicaDB.EntityFrameworkDB;
using Server.WCFServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Server {
    internal class Program {
        static void Main(string[] args) {
            IZeleznicaDatabaseHandler zeleznicaDatabaseHandler = new EFZeleznicaDatabaseHandler();
            IUserDatabaseHandler userDatabaseHandler = new EFUserDatabaseHandler();

            InitDatabase();

            using (ServiceHost zeleznicaHost = new ServiceHost(typeof(ZeleznicaService))) {
                using (ServiceHost userHost = new ServiceHost(typeof(UserService))) {
                    try {
                        zeleznicaHost.AddServiceEndpoint(typeof(IZeleznicaContract), new NetTcpBinding(), "net.tcp://localhost:4000/IZeleznicaContract");
                        userHost.AddServiceEndpoint(typeof(IUserContract), new NetTcpBinding(), "net.tcp://localhost:4000/IUserContract");

                        zeleznicaHost.Open();
                        userHost.Open();

                        Console.WriteLine("Server is running. Press any key to shut it down.");
                        TxtLogger.Instance.Log("Server started running", LogLevel.Info);
                        Console.ReadKey();
                    } catch (Exception ex) {
                        Console.WriteLine(ex.Message);
                        TxtLogger.Instance.Log(ex.Message, LogLevel.Error);
                    }

                    Console.WriteLine("Server is shutting down");
                    TxtLogger.Instance.Log("Server is shutting down", LogLevel.Info);
                    zeleznicaHost.Close();
                    userHost.Close();
                }
            }
        }

        static void InitDatabase() {
            IZeleznicaDatabaseHandler zeleznicaDatabaseHandler = new EFZeleznicaDatabaseHandler();
            IUserDatabaseHandler userDatabaseHandler = new EFUserDatabaseHandler();

            if (userDatabaseHandler.Read("admin") == null) {
                userDatabaseHandler.Create(new User() { Username = "admin", Password = "admin", FirstName = "Admin", LastName = "Admin", IsAdmin = true });
            }

            if (zeleznicaDatabaseHandler.ReadAll().Count == 0) {
                List<Stanica> stanice = new List<Stanica>() {
                    new Stanica() {
                        Naziv = "stanica1",
                        BrojKoloseka = 1,
                        Mesto = new Mesto() { Naziv = "mesto1", Drzava = Drzava.Srbija },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 1, Oznaka = "k1", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 2, Oznaka = "k2", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 3, Oznaka = "k3", Ulaz = VrstaUlaza.Desno }
                        }
                    },
                    new Stanica() {
                        Naziv = "stanica2",
                        BrojKoloseka = 2,
                        Mesto = new Mesto() { Naziv = "mesto2", Drzava = Drzava.Bugarska },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 4, Oznaka = "k4", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 5, Oznaka = "k5", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 6, Oznaka = "k6", Ulaz = VrstaUlaza.Desno }
                        }
                    },
                    new Stanica() {
                        Naziv = "stanica3",
                        BrojKoloseka = 3,
                        Mesto = new Mesto() { Naziv = "mesto3", Drzava = Drzava.Rumunija },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 7, Oznaka = "k7", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 8, Oznaka = "k8", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 9, Oznaka = "k9", Ulaz = VrstaUlaza.Desno }
                        }
                    },
                    new Stanica() {
                        Naziv = "stanica4",
                        BrojKoloseka = 4,
                        Mesto = new Mesto() { Naziv = "mesto4", Drzava = Drzava.Srbija },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 10, Oznaka = "k10", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 11, Oznaka = "k11", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 12, Oznaka = "k12", Ulaz = VrstaUlaza.Levo }
                        }
                    },
                    new Stanica() {
                        Naziv = "stanica5",
                        BrojKoloseka = 5,
                        Mesto = new Mesto() { Naziv = "mesto5", Drzava = Drzava.Rumunija },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 13, Oznaka = "k13", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 14, Oznaka = "k14", Ulaz = VrstaUlaza.Levo },
                            new Kolosek() { Naziv = 15, Oznaka = "k15", Ulaz = VrstaUlaza.Desno }
                        }
                    },
                    new Stanica() {
                        Naziv = "stanica6",
                        BrojKoloseka = 6,
                        Mesto = new Mesto() { Naziv = "mesto6", Drzava = Drzava.Srbija },
                        Koloseci = new List<Kolosek>() {
                            new Kolosek() { Naziv = 16, Oznaka = "k16", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 17, Oznaka = "k17", Ulaz = VrstaUlaza.Desno },
                            new Kolosek() { Naziv = 18, Oznaka = "k18", Ulaz = VrstaUlaza.Desno }
                        }
                    },
                };

                foreach (Stanica stanica in stanice) {
                    zeleznicaDatabaseHandler.CreateStanica(stanica);
                }

                Put p1 = new Put() {
                    Naziv = "put1",
                    Oznaka = "p1",
                    Stanice = new List<Stanica> {
                        stanice[0],
                        stanice[3],
                        stanice[4],
                    }
                };

                Put p2 = new Put() {
                    Naziv = "put2",
                    Oznaka = "p2",
                    Stanice = new List<Stanica> {
                        stanice[2],
                        stanice[5],
                        stanice[1],
                    }
                };

                zeleznicaDatabaseHandler.Create(p1);
                zeleznicaDatabaseHandler.Create(p2);
            }
        }
    }
}
