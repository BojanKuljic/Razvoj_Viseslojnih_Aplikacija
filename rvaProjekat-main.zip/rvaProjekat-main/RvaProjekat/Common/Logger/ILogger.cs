﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Logger {
    public enum LogLevel { Info, Warning, Error }
    public interface ILogger {
        void Log(string message, LogLevel logLevel);
    }
}
