﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Logger {
    public sealed class TxtLogger : ILogger {
        private static TxtLogger _instance;
        private static string filePath;

        private static readonly object constructorLock = new object();
        private static readonly object logLock = new object();

        private TxtLogger() { }

        public static TxtLogger Instance {
            get {
                // Double check lock
                if (_instance == null) {
                    lock (constructorLock) {
                        if (_instance == null) {
                            filePath = System.Reflection.Assembly.GetCallingAssembly().GetName().Name + "_logs.txt";
                            _instance = new TxtLogger();
                        }
                    }
                }
                return _instance;
            }
        }

        public void Log(string message, LogLevel logLevel) {
            lock (logLock) {
                using (StreamWriter writer = new StreamWriter(filePath, append: true)) {
                    writer.WriteLine(String.Format("[{0}] - {1} - {2}\n", logLevel.ToString(), DateTime.Now, message));
                }
            }
        }
    }
}
