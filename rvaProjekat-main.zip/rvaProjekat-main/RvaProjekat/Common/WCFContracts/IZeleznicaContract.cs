﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ServiceModel;
using Common.Model;
using Server.PutSearchStrategy;

namespace Common.WCFContracts {
    [ServiceContract]
    [ServiceKnownType(typeof(ByNazivPutSearchStrategy))]
    [ServiceKnownType(typeof(ByOznakaPutSearchStrategy))]
    public interface IZeleznicaContract {
        [OperationContract]
        List<Put> GetAllPutevi();

        [OperationContract]
        List<Put> FindPutevi(string searchQuery, IPutSearchStrategy putSearchStrategy);
        
        [OperationContract]
        List<Stanica> GetAllStanice();

        [OperationContract]
        List<Stanica> GetAllStaniceForPut(string nazivPuta);

        [OperationContract]
        bool AddPut(Put newPut);
        [OperationContract]
        bool AddStanica(Stanica newStanica);

        [OperationContract]
        bool UpdatePut(string oldNaziv, Put updatedPut);

        [OperationContract]
        void DeletePut(string naziv);

        [OperationContract]
        string DuplicatePut(string naziv);
    }
}
