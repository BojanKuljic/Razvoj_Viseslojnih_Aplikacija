﻿using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Server.PutSearchStrategy {
    [DataContract]
    public class ByNazivPutSearchStrategy : IPutSearchStrategy {
        public List<Put> FindPutevi(string searchQuery, List<Put> allPutevi) {
            List<Put> foundPutevi = new List<Put>();
            
            foreach (Put put in allPutevi) {
                if (put.Naziv.ToLower().Contains(searchQuery.ToLower())) {
                    foundPutevi.Add(put);
                }
            }

            return foundPutevi;
        }
    }
}
