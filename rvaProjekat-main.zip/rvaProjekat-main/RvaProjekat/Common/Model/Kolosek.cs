﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Common.Model {
    [DataContract]
    public enum VrstaUlaza {
        [EnumMember] Levo,
        [EnumMember] Desno
    }

    [DataContract]
    public class Kolosek {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int Naziv { get; set; }
        [DataMember]
        public string Oznaka { get; set; }
        [DataMember]
        public VrstaUlaza Ulaz { get; set; }
    }
}
