﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Common.Model {
    [DataContract]
    public class Put {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Naziv { get; set; }
        [DataMember]
        public string Oznaka { get; set; }
        [DataMember]
        public List<Stanica> Stanice { get; set; }

        public override string ToString() {
            string text = "";

            text += "Naziv: " + Naziv + "\n";
            text += "Oznaka: " + Oznaka + "\n";
            text += "Stanice: \n";

            if (Stanice != null) {
                foreach (Stanica stanica in Stanice) {
                    text += "\tNaziv: " + stanica.Naziv + "\n";
                    text += "\tBroj koloseka: " + stanica.BrojKoloseka + "\n";
                    text += "\tMesto: " + stanica.Mesto.Naziv + ", " + stanica.Mesto.Drzava + "\n";
                    text += "\tKoloseci: \n";

                    if (stanica.Koloseci != null) {
                        foreach (Kolosek kolosek in stanica.Koloseci) {
                            text += "\t\tNaziv: " + kolosek.Naziv + "\n";
                            text += "\t\tOznaka: " + kolosek.Oznaka + "\n";
                            text += "\t\tUlaz: " + kolosek.Ulaz + "\n\n";
                        }
                    }
                }
            }

            return text;

        }
    }
}
