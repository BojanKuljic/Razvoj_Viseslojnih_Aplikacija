﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Common.Model {
    [DataContract]
    public class Stanica {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Naziv { get; set; }
        [DataMember]
        public int BrojKoloseka { get; set; }
        [IgnoreDataMember]
        public List<Put> Putevi { get; set; }
        [DataMember]
        public Mesto Mesto { get; set; }
        [DataMember]
        public List<Kolosek> Koloseci { get; set; }

        public override string ToString()
        {
            return $"Stanica [Id={Id}, Naziv={Naziv}, BrojKoloseka={BrojKoloseka}] \n";
        }
    }
}
