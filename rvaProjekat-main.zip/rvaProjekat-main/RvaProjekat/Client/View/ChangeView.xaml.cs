﻿using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Client.View
{
    /// <summary>
    /// Interaction logic for ChangeView.xaml
    /// </summary>
    public partial class ChangeView : Window
    {

        private ZeleznicaChannelDecorator zcd = new ZeleznicaChannelDecorator();
        private Put oldPut;

        public ChangeView(Put put)
        {
            InitializeComponent();
            PutNazivTB.Text = put.Naziv;
            OznakaTB.Text = put.Oznaka;
            oldPut = put;
        }

        public MyICommand ChangePutCommand { get; set; }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (PutNazivTB.Text == string.Empty || OznakaTB.Text == string.Empty)
            {
                MessageBox.Show("Fill all filds", "Warning");
                return;
            }

            Put newPut = new Put() { Naziv = PutNazivTB.Text, Oznaka = OznakaTB.Text, Stanice = new List<Stanica>(oldPut.Stanice) };
            if (zcd.UpdatePut(oldPut.Naziv, newPut))
            {

                this.Close();
                MessageBox.Show("Changed Put", "Success");
            }
            else
            {
                MessageBox.Show("Error Changing Put", "Error");
            }
        }
    }
}
