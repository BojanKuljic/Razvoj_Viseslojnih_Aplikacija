﻿using Client.ViewModel;
using Client.WCFChannelDecorators;
using Common.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client.View
{
    /// <summary>
    /// Interaction logic for ProfileView.xaml
    /// </summary>
    public partial class ProfileView : UserControl
    {
        public ProfileView()
        {
            InitializeComponent();
            this.DataContext = new Client.ViewModel.ProfileViewModel();
        }

        private void ApplyEditButton_Click(object sender, RoutedEventArgs e)
        {
            if (FirstName.Text.Trim() == string.Empty || LastName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Fill all filds", "Warning");
                return;
            }

            string name = FirstName.Text;
            string lastName = LastName.Text;
            string username = NavigViewModel.Instance.CurrentUser.User.Username;


            UserChannelDecorator ucd = new UserChannelDecorator();
            if (ucd.UpdateUsersName(username, name, lastName))
            {
                NavigViewModel.Instance.CurrentUser.User.FirstName = name;
                NavigViewModel.Instance.CurrentUser.User.LastName = lastName;
                ProfileViewModel.Instance.CurrentUser.User.FirstName = name;
                ProfileViewModel.Instance.CurrentUser.User.LastName = lastName;
                FirstNameTB.Text = name;
                LastNameTB.Text = lastName;
                MessageBox.Show("User data updated!");
            }
            else
            {
                MessageBox.Show("Error has occurred.");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(MessageBox.Show("Are you sure?", "Logout", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            { 
                MainWindow.Instance.Show();
                Window parentWindow = Window.GetWindow(this);
                parentWindow.Close();
            }
        }
    }
}
