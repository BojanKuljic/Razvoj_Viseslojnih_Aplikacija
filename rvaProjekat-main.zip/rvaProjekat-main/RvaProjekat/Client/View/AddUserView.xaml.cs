﻿using Client.WCFChannelDecorators;
using Common.Logger;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client.View
{
    /// <summary>
    /// Interaction logic for AddUserView.xaml
    /// </summary>
    public partial class AddUserView : UserControl
    {
        private UserChannelDecorator ucd = new UserChannelDecorator();
        public AddUserView()
        {
            InitializeComponent();
            this.DataContext = new Client.ViewModel.AddUserViewModel();
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            string username = Username.Text;
            string password = Password.Password;
            string firstName = FirstName.Text;
            string lastName = LastName.Text;
            bool isAdmin = IsAdmin.IsChecked.Value;

            if (username == string.Empty || password == string.Empty || firstName == string.Empty || lastName == string.Empty)
            {
                MessageBox.Show("All fields must be filled!");
            }
            else
            {
                User newUser = new User();
                newUser.Username = username;
                newUser.Password = password;
                newUser.FirstName = firstName;
                newUser.LastName = lastName;
                newUser.IsAdmin = isAdmin;

                if (ucd.AddUser(newUser))
                {
                    MessageBox.Show("Add user successful!");
                }
                else
                {
                    MessageBox.Show("Unexpected Error!");
                }
            }
        }
    }
}
