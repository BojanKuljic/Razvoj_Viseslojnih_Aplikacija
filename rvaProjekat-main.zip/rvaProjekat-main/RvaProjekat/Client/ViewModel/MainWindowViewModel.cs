﻿using Client.Model;
using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Client.ViewModel {
    public class MainWindowViewModel : BindableBase {

       
    }
}
