﻿using Client.View;
using Client.WCFChannelDecorators;
using Common.Logger;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Client.ViewModel
{
    public class NewPutViewModel : BindableBase
    {

        private static NewPutViewModel _instance;
        private ZeleznicaChannelDecorator zcd = new ZeleznicaChannelDecorator();


        private ObservableCollection<Stanica> _stanice;
        public ObservableCollection<Stanica> Stanice
        {
            get => _stanice;
            set
            {
                _stanice = value;
                OnPropertyChanged(nameof(Stanice));
            }
        }

        private ObservableCollection<Stanica> _selectedStanice;
        public ObservableCollection<Stanica> SelectedStanice
        {
            get => _selectedStanice;
            set
            {
                _selectedStanice = value;
                OnPropertyChanged(nameof(SelectedStanice));
            }
        }

        public static NewPutViewModel Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new NewPutViewModel();

                return _instance;
            }
        }
        public NewPutViewModel()
        {
            LoadStaniceCommand = new MyICommand(LoadStanice);
            AddPutCommand = new MyICommand(AddPut);
            Stanice = new ObservableCollection<Stanica>();
            SelectedStanice = new ObservableCollection<Stanica>();
            LoadStanice();
        }
        private string _putNaziv;
        private string _oznaka;
        public MyICommand AddPutCommand { get; }

        public string PutNaziv
        {
            get => _putNaziv;
            set => SetProperty(ref _putNaziv, value);
        }

        public string Oznaka
        {
            get => _oznaka;
            set => SetProperty(ref _oznaka, value);
        }

        public MyICommand LoadStaniceCommand { get; }

        private void LoadStanice()
        {
            Stanice.Clear();
            var stanice = zcd.GetAllStanice();
            foreach (var stanica in stanice)
            {
                Stanice.Add(stanica);
            }
        }

        private void AddPut()
        {
            if (string.IsNullOrEmpty(PutNaziv) || string.IsNullOrEmpty(Oznaka) || SelectedStanice.Count == 0)
            {
                MessageBox.Show("Fill all fields");
                return;
            }

            var newPut = new Put
            {
                Id = 2, //Need better id 
                Naziv = PutNaziv,
                Oznaka = Oznaka,
                Stanice = new List<Stanica>(SelectedStanice),
            };

            if (zcd.AddPut(newPut))
            {
                TxtLogger.Instance.Log("Added new put: " + PutNaziv, LogLevel.Info);
                NewPutView.Instance.PutNazivTB.Text = "";
                NewPutView.Instance.OznakaTB.Text = "";
                PutNaziv = string.Empty;
                Oznaka = string.Empty;
                SelectedStanice = new ObservableCollection<Stanica>();
                MessageBox.Show("Successfully added new put");
            }
            else
            {
                MessageBox.Show("Failed to add new put");
            }
        }

    }
}
