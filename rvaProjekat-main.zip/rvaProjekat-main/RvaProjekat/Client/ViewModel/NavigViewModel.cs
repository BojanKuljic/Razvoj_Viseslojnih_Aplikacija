﻿using Client.Model;
using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel
{
    public class NavigViewModel : BindableBase
    {
        private static CurrentUser _currentUser = new CurrentUser { User = null };
        public MyICommand<string> NavCommand { get; private set; }
        private AddUserViewModel addUserViewModel = new AddUserViewModel();
        private ProfileViewModel profileViewModel = new ProfileViewModel();
        private NewPutViewModel newPutViewModel = new NewPutViewModel();
        private PuteviViewModel puteviViewModel = new PuteviViewModel();
        private BindableBase currentViewModel;


        public Visibility AdminMenuVisibility
        {
            get => CurrentUser.User.IsAdmin ? Visibility.Visible : Visibility.Hidden;
        }

        public Visibility RegularMenuVisibility
        {
            get => CurrentUser.User.IsAdmin ? Visibility.Hidden : Visibility.Visible;
        }

        private static NavigViewModel _instance;

        public static NavigViewModel Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new NavigViewModel();

                return _instance;
            }
        }


        public CurrentUser CurrentUser
        {
            get { return _currentUser; }
            set{ 
                _currentUser = value;
                OnPropertyChanged("CurrentUser");
            }
        }

        public NavigViewModel()
        {
            NavCommand = new MyICommand<string>(OnNav);
            CurrentViewModel = profileViewModel;
            //PropertyChanged += CurrentUser_PropertyChanged;
        }


        public BindableBase CurrentViewModel
        {
            get { return currentViewModel; }
            set
            {
                SetProperty(ref currentViewModel, value);
            }
        }

        //private void CurrentUser_PropertyChanged(object sender, PropertyChangedEventArgs e)
        //{
        //    if (e.PropertyName == nameof(CurrentUser))
        //    {
        //        profileViewModel.LoadUserData(CurrentUser);
        //    }
        //}

        public void OnNav(string destination)
        {

            switch (destination)
            {
                case "AddUser":
                    CurrentViewModel = addUserViewModel;
                    break;
                case "Profile":
                    CurrentViewModel = profileViewModel;
                    break;
                case "NewPut":
                    CurrentViewModel = newPutViewModel;
                    break;
                case "Putevi":
                    CurrentViewModel = puteviViewModel;
                    break;
                case "Change":
                    CurrentViewModel = newPutViewModel;
                    break;
            }

        }

    }
    
}
