﻿using Client.Model;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.ViewModel {
    public class ProfileViewModel : BindableBase {



        private static ProfileViewModel _instance;

        public static ProfileViewModel Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ProfileViewModel();

                return _instance;
            }
        }

        private static CurrentUser _currentUser = new CurrentUser { User = null };

        public ProfileViewModel()
        {
        }

        public CurrentUser CurrentUser
        {
            get { return _currentUser; }
            set
            {
                _currentUser = value;
                OnPropertyChanged("CurrentUser");
                OnPropertyChanged("Username");
                OnPropertyChanged("FirstName");
                OnPropertyChanged("LastName");
            }
        }
        public string Username
        {
            get => _currentUser.User.Username;
        }

        public string FirstName
        {
            get => _currentUser.User.FirstName;
        }

        public string LastName
        {
            get => _currentUser.User.LastName;
        }

        public void LoadUserData(User user)
        {
            CurrentUser = new CurrentUser() {User = user };
        }

    }
}