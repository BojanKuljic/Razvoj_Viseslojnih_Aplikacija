﻿using Client.Commands;
using Client.View;
using Client.WCFChannelDecorators;
using Common.Model;
using Server.PutSearchStrategy;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Client.ViewModel
{
    public class PuteviViewModel : BindableBase
    {

        private ZeleznicaChannelDecorator zcd = new ZeleznicaChannelDecorator();

        public static ObservableCollection<Put> putevi;
        public static ObservableCollection<Stanica> stanice;
        public static ObservableCollection<Kolosek> koloseci;
        public static ObservableCollection<Mesto> mesta;
        private Put selectedPut;
        private Stanica selectedStanica;
        private string query;
        private Mesto mesto;
        private bool isByNazivChecked;
        private bool isByOznakaChecked;

        public MyICommand DeleteCommand { get; set; }
        public MyICommand ChangeCommand { get; set; }
        public MyICommand SearchCommand { get; set; }
        public MyICommand DuplicateCommand { get; set; }
        public MyICommand UndoCommand { get; set; }
        public MyICommand RedoCommand { get; set; }
        public MyICommand ShowAllCommand { get; set; }

        public static int currentCommand;
        public static List<Command> commands = new List<Command>();

        public void Refresh()
        {
            lock (Putevi)
            {
                List<Put> putevi = zcd.GetAllPutevi();
                if (putevi != null)
                    Putevi = new ObservableCollection<Put>(putevi);
                else
                    Putevi = new ObservableCollection<Put>();

                OnPropertyChanged("Putevi");
            }
        }



        public PuteviViewModel()
        {
            LoadPutevi();
            DeleteCommand = new MyICommand(OnDelete, CanDelete);
            ChangeCommand = new MyICommand(Change, CanChange);
            SearchCommand = new MyICommand(Search);
            ShowAllCommand = new MyICommand(LoadPutevi);
            DuplicateCommand = new MyICommand(Duplicate, CanDuplicate);
            UndoCommand = new MyICommand(Undo);
            RedoCommand = new MyICommand(Redo);
            IsByNazivChecked = true;

            new Thread(() =>
            {
                while (true)
                {
                    Thread.Sleep(60000);
                    Refresh();
                }
            }).Start();
        }

        public void LoadPutevi()
        {
            List<Put> putevi = zcd.GetAllPutevi();
            if (putevi != null)
                Putevi = new ObservableCollection<Put>(putevi);
            else
                Putevi = new ObservableCollection<Put>();

            OnPropertyChanged("Putevi");
        }


        public ObservableCollection<Put> Putevi
        {
            get
            {
                return putevi;
            }
            set
            {
                putevi = value;
                OnPropertyChanged("Putevi");
            }
        }

        public ObservableCollection<Stanica> Stanice
        {
            get
            {
                return stanice;
            }
            set
            {
                stanice = value;
                OnPropertyChanged("Stanice");
            }
        }

        public ObservableCollection<Kolosek> Koloseci
        {
            get
            {
                return koloseci;
            }
            set
            {
                koloseci = value;
                OnPropertyChanged("Koloseci");
            }
        }

        public ObservableCollection<Mesto> Mesta
        {
            get
            {
                return mesta;
            }
            set
            {
                mesta = value;
                OnPropertyChanged("Mesta");
            }
        }

        public bool IsByNazivChecked
        {
            get
            {
                return isByNazivChecked;
            }

            set
            {
                if (isByNazivChecked != value)
                {
                    isByNazivChecked = value;
                    if (isByNazivChecked)
                    {
                        IsByOznakaChecked = false;
                    }
                    OnPropertyChanged("IsByNazivChecked");
                    OnPropertyChanged("IsByOznakaChecked");
                }
            }
        }

        public bool IsByOznakaChecked
        {
            get
            {
                return isByOznakaChecked;
            }

            set
            {
                if (isByOznakaChecked != value)
                {
                    isByOznakaChecked = value;
                    if (isByOznakaChecked)
                    {
                        IsByNazivChecked = false;
                    }
                    OnPropertyChanged("IsByNazivChecked");
                    OnPropertyChanged("IsByOznakaChecked");
                }
            }

        }

        public Put SelectedPut
        {
            get
            {
                Koloseci = null;
                Mesta = null;
                return selectedPut;
            }

            set
            {
                if (selectedPut != value)
                {
                    selectedPut = value;
                    DeleteCommand.RaiseCanExecuteChanged();
                    ChangeCommand.RaiseCanExecuteChanged();
                    DuplicateCommand.RaiseCanExecuteChanged();
                    SearchCommand.RaiseCanExecuteChanged();
                    Koloseci = null;
                    Mesta = null;
                    if (value != null)
                        Stanice = new ObservableCollection<Stanica>(selectedPut.Stanice);
                    else
                        Stanice = new ObservableCollection<Stanica>();
                }
            }
        }

        public Stanica SelectedStanica
        {
            get
            {
                return selectedStanica;
            }

            set
            {
                if (selectedStanica != value)
                {
                    selectedStanica = value;
                    Mesta = new ObservableCollection<Mesto>();
                    if (value != null)
                    {
                        Koloseci = new ObservableCollection<Kolosek>(selectedStanica.Koloseci);
                        Mesta.Add(selectedStanica.Mesto);
                    }
                    else
                    {
                        Koloseci = new ObservableCollection<Kolosek>();
                    }

                }
            }
        }

        public string Query
        {
            get
            {
                return query;
            }

            set
            {
                if (query != value)
                {
                    query = value;
                    ChangeCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private void OnDelete()
        {
            Command command = new CommandDelete(SelectedPut);
            command.Execute();
            if (commands.Count > currentCommand)
            {
                commands.RemoveRange(currentCommand, commands.Count - currentCommand);
            }
            commands.Add(command);
            currentCommand++;
            Putevi.Remove(SelectedPut);
            OnPropertyChanged("Putevi");
            Refresh();
        }

        private bool CanDelete()
        {
            return SelectedPut != null;
        }

        private void Change()
        {
            ChangeView cv = new ChangeView(SelectedPut);
            cv.Show();
        }

        private bool CanChange()
        {
            return SelectedPut != null;
        }

        private void Search()
        {
            if (Query.Trim() == "" || Query == null)
            {
                MessageBox.Show("Warning", "You need to imput at least one character to search");
                return;
            }

            if (IsByNazivChecked)
            {
                List<Put> putevi = zcd.FindPutevi(Query, new ByNazivPutSearchStrategy());
                if (putevi != null)
                    Putevi = new ObservableCollection<Put>(putevi);
                else
                    Putevi = new ObservableCollection<Put>();
            }
            else
            {
                List<Put> putevi = zcd.FindPutevi(Query, new ByOznakaPutSearchStrategy());
                if (putevi != null)
                    Putevi = new ObservableCollection<Put>(putevi);
                else
                    Putevi = new ObservableCollection<Put>();
            }
        }

        private void Duplicate()
        {
            Command command = new CommandDuplicate(SelectedPut);
            command.Execute();
            if (commands.Count > currentCommand)
            {
                commands.RemoveRange(currentCommand, commands.Count - currentCommand);
            }
            commands.Add(command);
            currentCommand++;
            Refresh();
        }

        private bool CanDuplicate()
        {
            return SelectedPut != null;
        }

        private void Undo()
        {
            if (currentCommand > 0)
            {
                Command command = commands[--currentCommand];
                command.Unexecute();
                Refresh();
            }
        }

        private void Redo()
        {
            if (currentCommand < commands.Count)
            {
                Command command = commands[currentCommand++];
                command.Execute();
                Refresh();
            }
        }

    }
}
