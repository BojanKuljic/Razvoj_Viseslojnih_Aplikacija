﻿using Client.WCFChannelDecorators;
using Common.Logger;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Client.ViewModel {
    public class AddUserViewModel : BindableBase {
        private UserChannelDecorator ucd = new UserChannelDecorator();
        private string firstName;
        private string lastName;
        private string username;
        private string password;
        private bool isAdmin;
        private List<string> roleList;
        public MyICommand AddUserCommand { get; set; }

        public AddUserViewModel() {
            AddUserCommand = new MyICommand(AddUser, CanAddUser);
            RoleList = new List<string> { "admin", "customer" };
        }

        public List<string> RoleList {
            get {
                return roleList;
            }

            set {
                if (roleList != value) {
                    roleList = value;
                }
            }
        }

        public string Password {
            get {
                return password;
            }
            set {
                if (password != value) {
                    password = value;
                    OnPropertyChanged("Password");
                    AddUserCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string Username {
            get {
                return username;
            }
            set {
                if (username != value) {
                    username = value;
                    OnPropertyChanged("Username");
                    AddUserCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string FirstName {
            get {
                return firstName;
            }
            set {
                if (firstName != value) {
                    firstName = value;
                    OnPropertyChanged("FirstName");
                    AddUserCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string LastName {
            get {
                return lastName;
            }
            set {
                if (lastName != value) {
                    lastName = value;
                    OnPropertyChanged("LastName");
                    AddUserCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public bool IsAdmin {
            get {
                return isAdmin;
            }
            set {
                if (isAdmin != value) {
                    isAdmin = value;
                    OnPropertyChanged("LastName");
                    AddUserCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private bool CanAddUser() {
            return !String.IsNullOrEmpty(firstName) && !String.IsNullOrEmpty(lastName) && !String.IsNullOrEmpty(username) && !String.IsNullOrEmpty(password);
        }

        private void AddUser()
        {
            if (FirstName.Trim() == "" || FirstName == null  || LastName == null || LastName.Trim() == "" || Password.Trim() == "" || Password == null || Username == null || Username.Trim() == "")
            {
                MessageBox.Show("Fill all filds", "Warning");
                return;
            }
            User newUser = new User
            {
                FirstName = FirstName,
                LastName = LastName,
                Password = Password,
                Username = Username,
                IsAdmin = IsAdmin
            };
            ucd.AddUser(newUser);
        }

        

    }
}
