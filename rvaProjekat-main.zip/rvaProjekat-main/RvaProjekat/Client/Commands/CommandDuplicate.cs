﻿using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Client.Commands
{
    public class CommandDuplicate : Command
    {
        public CommandDuplicate(Put put) : base(put) { }
        private string duplicate;

        public override void Execute()
        {
            if (put != null)
            {
                duplicate = zcd.DuplicatePut(put.Naziv);
            }
        }

        public override void Unexecute()
        {
            if (put != null)
            {
                zcd.DeletePut(duplicate);
            }
        }
    }
}
