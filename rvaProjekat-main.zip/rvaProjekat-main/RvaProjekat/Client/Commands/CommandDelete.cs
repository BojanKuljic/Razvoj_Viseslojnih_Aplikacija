﻿using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Client.Commands 
{
    public class CommandDelete : Command
    {
        public CommandDelete(Put put) : base(put) { }

        public override void Execute()
        {
            if (put != null)
            {
                zcd.DeletePut(put.Naziv);
            }
        }

        public override void Unexecute()
        {
            if (put != null)
            {
                zcd.AddPut(put);
            }
        }
    }
}
