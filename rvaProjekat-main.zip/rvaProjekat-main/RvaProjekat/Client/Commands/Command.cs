﻿using Client.WCFChannelDecorators;
using Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Commands 
{
    public abstract class Command
    {
        protected Put put;
        protected ZeleznicaChannelDecorator zcd = new ZeleznicaChannelDecorator();

        public Command(Put put)
        {
            this.put = put;
        }

        public abstract void Execute();
        public abstract void Unexecute();
    }
}
