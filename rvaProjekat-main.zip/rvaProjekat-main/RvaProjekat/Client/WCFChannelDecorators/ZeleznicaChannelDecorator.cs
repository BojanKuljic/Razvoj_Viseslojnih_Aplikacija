﻿using Common.Logger;
using Common.Model;
using Common.WCFContracts;
using Server.PutSearchStrategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Client.WCFChannelDecorators {
    public class ZeleznicaChannelDecorator : IZeleznicaContract {
        IZeleznicaContract channel;

        public ZeleznicaChannelDecorator() {
            ChannelFactory<IZeleznicaContract> channelFactory = new ChannelFactory<IZeleznicaContract>(new NetTcpBinding(), "net.tcp://localhost:4000/IZeleznicaContract");
            channel = channelFactory.CreateChannel();
        }

        public bool AddPut(Put newPut) {
            try {
                bool result = channel.AddPut(newPut);

                if (result) {
                    TxtLogger.Instance.Log("Put '" + newPut.Naziv + "' added", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("Put '" + newPut.Naziv + "' could not be added", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return false;
            }
        }

        public void DeletePut(string naziv) {
            try {
                channel.DeletePut(naziv);
                TxtLogger.Instance.Log("Put '" + naziv + "' deleted", LogLevel.Info);

            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
            }
        }

        public string DuplicatePut(string naziv) {
            try {
                string result = channel.DuplicatePut(naziv);

                if (result == null) {
                    TxtLogger.Instance.Log("Put '" + naziv + "' duplicated", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("Put '" + naziv + "' could not be duplicated", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public List<Stanica> GetAllStanice() {
            try {
                var stanice = channel.GetAllStanice();

                TxtLogger.Instance.Log("Stanice received", LogLevel.Info);

                return stanice;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public List<Stanica> GetAllStaniceForPut(string nazivPuta) {
            try {
                var stanice = channel.GetAllStaniceForPut(nazivPuta);

                TxtLogger.Instance.Log("Stanice for put '" + nazivPuta + "' + received", LogLevel.Info);

                return stanice;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public List<Put> FindPutevi(string searchQuery, IPutSearchStrategy putSearchStrategy) {
            try {
                var putevi = channel.FindPutevi(searchQuery, putSearchStrategy);

                TxtLogger.Instance.Log("Put search finished", LogLevel.Info);

                return putevi;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public List<Put> GetAllPutevi() {
            try {
                var putevi = channel.GetAllPutevi();

                TxtLogger.Instance.Log("Putevi received", LogLevel.Info);

                return putevi;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public bool UpdatePut(string oldNaziv, Put updatedPut) {
            try {
                bool result = channel.UpdatePut(oldNaziv, updatedPut);

                if (result) {
                    TxtLogger.Instance.Log("Put '" + oldNaziv + "' updated", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("Put '" + oldNaziv + "' could not be updated", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return false;
            }
        }

        public bool AddStanica(Stanica newStanica) {
            try {
                var result = channel.AddStanica(newStanica);

                if (result) {
                    TxtLogger.Instance.Log("Stanica '" + newStanica.Naziv + "' added", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("Stanica '" + newStanica.Naziv + "' could not be added", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return false;
            }
        }
    }
}
