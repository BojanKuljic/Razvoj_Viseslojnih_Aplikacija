﻿using Common.Logger;
using Common.Model;
using Common.WCFContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Client.WCFChannelDecorators {
    public class UserChannelDecorator : IUserContract {

        IUserContract channel;

        public UserChannelDecorator() {
            ChannelFactory<IUserContract> channelFactory = new ChannelFactory<IUserContract>(new NetTcpBinding(), "net.tcp://localhost:4000/IUserContract");
            channel = channelFactory.CreateChannel();
        }

        public bool AddUser(User newUser) {
            try {
                bool result = channel.AddUser(newUser);

                if (result) {
                    TxtLogger.Instance.Log("User '" + newUser.Username + "' added", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("User '" + newUser.Username + "' could not be added", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return false;
            }
        }

        public User AuthenticateUser(string username, string password) {
            try {
                User user = channel.AuthenticateUser(username, password);

                if (user != null) {
                    TxtLogger.Instance.Log("User '" + username + "' logged in", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("Authentication failed", LogLevel.Warning);
                }

                return user;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return null;
            }
        }

        public bool UpdateUsersName(string username, string newFirstName, string newLastName) {
            try {
                bool result = channel.UpdateUsersName(username, newFirstName, newLastName);

                if (result) {
                    TxtLogger.Instance.Log("User '" + username + "' updated", LogLevel.Info);
                } else {
                    TxtLogger.Instance.Log("User '" + username + "' could not be updated", LogLevel.Warning);
                }

                return result;
            } catch (Exception e) {
                TxtLogger.Instance.Log("WCF communication exception: " + e.Message, LogLevel.Error);
                return false;
            }
        }
    }
}
